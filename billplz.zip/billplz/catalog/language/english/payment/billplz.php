<?php
/**
 * BillPlz OpenCart Plugin
 * 
 * @package Payment Gateway
 * @author mohd hafeez johari
 * @version 1.0
 */
 
// Text
$_['text_title'] = 'BillPlz Payment Gateway (Maybank2u, FPX, etc )</br><img src="admin/view/image/payment/billplz.png" alt="BillPlz Payment Gateway" title="BillPlz Payment Gateway" style="border: 0px solid #EEEEEE;"/>';