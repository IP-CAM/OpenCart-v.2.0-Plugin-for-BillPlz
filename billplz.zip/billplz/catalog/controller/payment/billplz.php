<?php
/**
 * BillPlz OpenCart Plugin
 * 
 * @package Payment Gateway
 * @author mohd hafeez johari
 * @version 1.0
 */

class ControllerPaymentBillPlz extends Controller 
{
    public function index() 
    {
        $data['button_confirm'] = $this->language->get('button_confirm');

        $this->load->model('checkout/order');

        $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);

        $data['url'] = 'https://www.billplz.com/api/v2/bills';
        $data['amount'] = $this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false);
        $data['bill_name'] = $order_info['payment_firstname'] . ' ' . $order_info['payment_lastname'];
        $data['bill_email'] = $order_info['email'];
        $data['bill_mobile'] = $order_info['telephone'];
        $data['deliver'] = false;
        $data['api_key'] = $this->config->get('billplz_mid');
        $data['collection_id'] = $this->config->get('billplz_vkey');
        $data['callback_url'] = $this->url->link('payment/billplz/callback_ipn', '', 'SSL');
        $data['redirect_url'] = $this->url->link('payment/billplz/return_ipn', '', 'SSL');
        
        $url = $data['url'];
        $ch = curl_init($url);
        $fields = array(
                        'collection_id' => $data['collection_id'],
                        'email' => $data['bill_email'],
                        'name' => $data['bill_name'],
                        'amount' => $data['amount'] * 100,
                        'mobile' => $data['bill_mobile'],
                        'callback_url' => $data['callback_url'],
                        'redirect_url' => $data['redirect_url'],
                        'deliver' => $data['deliver'],
                        'metadata[order_id]' => $this->session->data['order_id']
                );

        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_USERPWD, $data['api_key']);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        //execute post
        $result = curl_exec($ch);
        
        if ($result === true) 
        {
            $info = curl_getinfo($ch);
            curl_close($ch);
            die('error occured during curl exec. Additional info: ' . var_export($info));
        }

        curl_close($ch);
        
        $result_decode = json_decode($result,1);

        $data['action'] = $result_decode['url'];
        
        if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/payment/billplz.tpl')) 
        {
            return $this->load->view($this->config->get('config_template') . '/template/payment/billplz.tpl', $data);
        }
        else 
        {
            return $this->load->view('default/template/payment/billplz.tpl', $data);
        }
    }

    public function return_ipn() 
    {
        $data['url'] = 'https://www.billplz.com/api/v2/bills/';
        $bill_id = $_REQUEST['billplz']['id'];
        $data['api_key'] = $this->config->get('billplz_mid');

        $url = $data['url'].$bill_id;

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_USERPWD, $data['api_key']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        //execute post
        $result = curl_exec($ch);
        
        if ($result === true) 
        {
            $info = curl_getinfo($ch);
            curl_close($ch);
            die('error occured during curl exec. Additional info: ' . var_export($info));
        }

        curl_close($ch);

        $this->load->model('checkout/order');

        $return_data = json_decode($result,1);

        $order_info = $this->model_checkout_order->getOrder($return_data['metadata']['order_id']); // orderid
        
        $vkey = $this->config->get('billplz_vkey');

        $orderid = $return_data['metadata']['order_id'];
        $status = $return_data['paid'];

        $order_status_id = $this->config->get('config_order_status_id');
        
        if($status)  
        {
            $order_status_id = $this->config->get('billplz_completed_status_id');
            $this->model_checkout_order->addOrderHistory($orderid, $order_status_id);
            echo '<html>' . "\n";
            echo '<head>' . "\n";
            echo '  <meta http-equiv="Refresh" content="0; url=' . $this->url->link('checkout/success') . '">' . "\n";
            echo '</head>' . "\n";
            echo '<body>' . "\n";
            echo '  <p>Please follow <a href="' . $this->url->link('checkout/success') . '">link</a>!</p>' . "\n";
            echo '</body>' . "\n";
            echo '</html>' . "\n";
            exit();
        } 
        else 
        {
            $order_status_id = $this->config->get('billplz_failed_status_id');
            $this->model_checkout_order->addOrderHistory($orderid, $order_status_id);
            echo '<html>' . "\n";
            echo '<head>' . "\n";
            echo '  <meta http-equiv="Refresh" content="0; url=' . $this->url->link('checkout/failure') . '">' . "\n";
            echo '</head>' . "\n";
            echo '<body>' . "\n";
            echo '  <p>Please follow <a href="' . $this->url->link('checkout/failure') . '">link</a>!</p>' . "\n";
            echo '</body>' . "\n";
            echo '</html>' . "\n";
            exit();
        }
        
    }
     
    public function callback_ipn()   
    {
        $data['url'] = 'https://www.billplz.com/api/v2/bills/';
        $bill_id = $_REQUEST['billplz']['id'];
        $data['api_key'] = $this->config->get('billplz_mid');

        $url = $data['url'].$bill_id;

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_USERPWD, $data['api_key']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        //execute post
        $result = curl_exec($ch);
        
        if ($result === true) 
        {
            $info = curl_getinfo($ch);
            curl_close($ch);
            die('error occured during curl exec. Additional info: ' . var_export($info));
        }

        curl_close($ch);

        $this->load->model('checkout/order');

        $return_data = json_decode($result,1);

        $order_info = $this->model_checkout_order->getOrder($return_data['metadata']['order_id']); // orderid
        
        $vkey = $this->config->get('billplz_vkey');

        $orderid = $return_data['metadata']['order_id'];
        $status = $return_data['paid'];

        $order_status_id = $this->config->get('config_order_status_id');
        
        if($status)  
        {
            $order_status_id = $this->config->get('billplz_completed_status_id');
            $this->model_checkout_order->addOrderHistory($orderid, $order_status_id);
        } 
        else 
        {
            $order_status_id = $this->config->get('billplz_failed_status_id');
            $this->model_checkout_order->addOrderHistory($orderid, $order_status_id);
        }
    }
}